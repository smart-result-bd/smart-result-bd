// SMART RESULT BD - Google Apps Script cloud backup
// Deploy as Web app: Execute as Me; Who has access: Anyone
const FILE_NAME = 'SMART_RESULT_BD_cloud_backup.json';
function doPost(e) {
  try {
    const payload = e && e.postData && e.postData.contents;
    if (!payload) throw new Error('Empty backup');
    const parsed = JSON.parse(payload);
    if (!parsed.subjects || !parsed.students) throw new Error('Invalid backup format');
    const files = DriveApp.getFilesByName(FILE_NAME);
    const content = JSON.stringify(parsed, null, 2);
    if (files.hasNext()) files.next().setContent(content);
    else DriveApp.createFile(FILE_NAME, content, MimeType.PLAIN_TEXT);
    return json_({ok:true, message:'Backup saved'});
  } catch (err) { return json_({ok:false, error:String(err)}); }
}
function doGet(e) {
  if (e && e.parameter && e.parameter.action === 'restore') {
    const files = DriveApp.getFilesByName(FILE_NAME);
    if (!files.hasNext()) return json_({error:'No backup found'});
    return ContentService.createTextOutput(files.next().getBlob().getDataAsString()).setMimeType(ContentService.MimeType.JSON);
  }
  return json_({ok:true, service:'SMART RESULT BD backup'});
}
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
